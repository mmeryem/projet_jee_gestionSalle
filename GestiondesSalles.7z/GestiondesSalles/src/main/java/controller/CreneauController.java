package controller;
	import java.io.IOException;
import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
	import java.util.List;
	import javax.servlet.ServletException;
	import javax.servlet.annotation.WebServlet;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;
	import com.google.gson.Gson;
	import beans.Creneau;
	import service.CreneauService;

	/**
	 * Servlet implementation class SalleController
	 */
	@WebServlet(name = "CreneauController", urlPatterns = { "/admin/CreneauController", "/client/CreneauController" })
	public class CreneauController extends HttpServlet {

		CreneauService cs = new CreneauService();

		/**
		 * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
		 * methods.
		 *
		 * @param request  servlet request
		 * @param response servlet response
		 * @throws ServletException if a servlet-specific error occurs
		 * @throws IOException      if an I/O error occurs
		 */
		protected void processRequest(HttpServletRequest request, HttpServletResponse response)
				throws ServletException, IOException {
			  if (request.getParameter("op") != null) {
		            if (request.getParameter("op").equals("load")) {
		                response.setContentType("application/json");
		                List<Creneau> creneaus = cs.findAll();
		                Gson json = new Gson();
		                response.getWriter().write(json.toJson(creneaus));
		            }else if(request.getParameter("op").equals("delete")){
		            	System.out.println("Go to delete");
		                int id = Integer.parseInt(request.getParameter("id"));
		                cs.delete(cs.findById(id));
		                response.setContentType("application/json");
		                List<Creneau> creneaus = cs.findAll();
		                Gson json = new Gson();
		                response.getWriter().write(json.toJson(creneaus));
		                
		            }else if(request.getParameter("op").equals("update")){
		            	System.out.println(" Go to update");
		            	System.out.println(request.getParameter("heureDebut"));
		            	System.out.println(request.getParameter("heureFin"));
		            	 String heureDebut =request.getParameter("heureDebut");
		                 String heureFin = request.getParameter("heureFin");
		                 
		                 
		                 
		                 
		                 Time heureDeb = Time.valueOf(request.getParameter("heureDebut") + ":00");
		                 Time heureFi = Time.valueOf(request.getParameter("heureFin") + ":00");
		            	 DateFormat formatter = new SimpleDateFormat("hh:mm:ss");
		            	 Time heuredeb=null;
		            	 Time heurefi = null;
						try {
							heuredeb = (Time) formatter.parse(heureDebut);
							 heurefi = (Time) formatter.parse(heureFin);
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
		            	 
		                int id = Integer.parseInt(request.getParameter("id"));
		               
		              
		                System.out.println(id);
		                
		                cs.update(new Creneau(id,heureDeb, heureFi));
		              //  Salle salle=ss.findById(id);
		              // ss.update(Creneau);
		                response.setContentType("application/json");
		                List<Creneau> creneaus = cs.findAll();
		                Gson json = new Gson();
		                response.getWriter().write(json.toJson(creneaus));
		                
		            }
		        } else {
		        	System.out.println("create");
		            String heureDebut = request.getParameter("heureDebut");
		            System.out.println(heureDebut);
		            String heureFin=request.getParameter("heureFin");
		            System.out.println(heureFin);
		           // Time heureDeb = Time.valueOf(request.getParameter("heureDebut")+ ":00");
		           // Time heureFi = Time.valueOf(request.getParameter("heureFin")+ ":00");
		            Time heureDeb = Time.valueOf(request.getParameter("heureDebut") + ":00");
		            Time heureFi = Time.valueOf(request.getParameter("heureFin") + ":00");
		            //  Date dateAchat = new Date(request.getParameter("dateAchat").replace("-", "/"));
		           // DateFormat formatter = new SimpleDateFormat("hh:mm:ss");
		       //	 Time heureDeb=null;
		      // 	Time heurefi=null;
			//	try {
			//		heureDeb = (Time) formatter.parse(heureDebut);
			//		heurefi = (Time) formatter.parse(heureFin);
			//	} catch (ParseException e) {
				//	// TODO Auto-generated catch block
			//		e.printStackTrace();
			//	}
		       	  
		            System.out.println("avant creat");
		            cs.create(new Creneau(heureDeb, heureFi));
		            System.out.println("apres json");
		            System.out.println("avant json");
		            response.setContentType("application/json");
		            System.out.println("apres json");
		            List<Creneau> creneaus = cs.findAll();
		            System.out.println("avant Gson");
		            Gson json = new Gson();
		            response.getWriter().write(json.toJson(creneaus));
		            System.out.println("apres Gson");
		            System.out.println("Bye");
		        }

		    }

	}

