package test;
	import beans.Admin;
	import service.AdminService;

	public class TestAdmin {
		
		     public static void main(String[] args){
		    AdminService us = new AdminService();
		    us.create(new Admin("meryem9@gmail.com","987654","Meryem","Meryama",null));
		    
}
}



